import java.awt.EventQueue;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

import Services.AccountManager;
import pages.Order;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import pages.main;

public class Final extends JFrame {

    static String port = "3307";
    static String DBIdentifier = "point_of_sale";
    static String masterUsername = "root";
    static String masterPassword = "your_password";

    public static Connection getConnection() throws SQLException {
        String url = "jdbc:mysql://localhost:" + port + "/" + DBIdentifier;
        return DriverManager.getConnection(url, masterUsername, masterPassword);
    }

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField user_input;
    private JPasswordField pass_input;
    private JTextField reg_user_input;
    private JTextField reg_lastname_input;
    private JPasswordField reg_password_input;
    private JPanel loginPanel; // Declare loginPanel as a class-level field
    private JPanel registerPanel; // Declare registerPanel as a class-level field
    public static Final frame = new Final();

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public Final() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 800, 600);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        loginPanel = createLoginPanel();
        loginPanel.setBounds(400, 0, 400, 600); // Adjusted bounds for right side
        contentPane.add(loginPanel);

        registerPanel = createRegisterPanel();
        registerPanel.setBounds(0, 0, 400, 600); // Adjusted bounds for left side
        contentPane.add(registerPanel);
        registerPanel.setVisible(false);

        // Image on login panel
        JLabel loginImageLabel = new JLabel();
        loginImageLabel.setIcon(new ImageIcon("images/login.png"));
        loginImageLabel.setBounds(3, 0, 400, 561); // Adjusted bounds to cover the login panel area
        contentPane.add(loginImageLabel);

        // Image on register panel
        JLabel registerImageLabel = new JLabel();
        registerImageLabel.setIcon(new ImageIcon("images/register.png"));
        registerImageLabel.setBounds(403, 0, 400, 561); // Adjusted bounds to cover the register panel area
        contentPane.add(registerImageLabel);
    }

    private JPanel createLoginPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(new Color(39, 55, 85));

        JLabel welcome = new JLabel("LOGIN");
        welcome.setForeground(new Color(255, 255, 255));
        welcome.setBounds(129, 110, 145, 50);
        welcome.setFont(new Font("Tahoma", Font.BOLD, 40));
        panel.add(welcome);

        JLabel user_lbl = new JLabel("Username");
        user_lbl.setForeground(new Color(255, 255, 255));
        user_lbl.setBounds(37, 215, 73, 25);
        user_lbl.setFont(new Font("Tahoma", Font.PLAIN, 15));
        panel.add(user_lbl);

        JPanel userPanel = createRoundedPanel();
        userPanel.setBounds(37, 251, 323, 30);
        panel.add(userPanel);

        user_input = new JTextField();
        user_input.setBounds(0, 0, 323, 30);
        userPanel.add(user_input);

        JLabel pass_lbl = new JLabel("Password");
        pass_lbl.setForeground(new Color(255, 255, 255));
        pass_lbl.setBounds(37, 287, 73, 25);
        pass_lbl.setFont(new Font("Tahoma", Font.PLAIN, 15));
        panel.add(pass_lbl);

        JPanel passPanel = createRoundedPanel();
        passPanel.setBounds(37, 317, 323, 30);
        panel.add(passPanel);

        pass_input = new JPasswordField();
        pass_input.setBounds(0, 0, 323, 30);
        passPanel.add(pass_input);

        // Forgot Password Link
        JLabel forgotPassword = new JLabel("<html><u>Forgot Password?</u></html>");
        forgotPassword.setForeground(Color.WHITE);
        forgotPassword.setFont(new Font("Tahoma", Font.PLAIN, 12));
        forgotPassword.setBounds(37, 350, 100, 20);
        forgotPassword.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                // Implement your logic for forgot password action here
                JOptionPane.showMessageDialog(null, "Forgot Password.");
            }
        });
        panel.add(forgotPassword);

        JButton loginBtn = new JButton("Login");
        loginBtn.setForeground(new Color(39, 55, 85));
        loginBtn.setBorderPainted(false);
        loginBtn.setBackground(new Color(255, 255, 255));
        loginBtn.setBounds(149, 387, 89, 23);
        loginBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String username = user_input.getText();
                String password = new String(pass_input.getPassword());
                if (AccountManager.checkForMatch(username, password)) {
                    Order coffee = new Order(AccountManager.getUserByUsername(username));
                    main mainFrame = new main();
                    coffee.setVisible(true);
                    mainFrame.setVisible(true);
                    frame.setVisible(false);
                    System.out.println(password);
                } else {
                    JOptionPane.showMessageDialog(null, "Incorrect username or password!");
                }
            }
        });
        loginBtn.setFont(new Font("Tahoma", Font.PLAIN, 15));
        panel.add(loginBtn);

        JLabel no_acc = new JLabel("Don't have an account?");
        no_acc.setForeground(new Color(255, 255, 255));
        no_acc.setBounds(63, 452, 164, 14);
        no_acc.setFont(new Font("Tahoma", Font.PLAIN, 15));
        panel.add(no_acc);

        JButton registerBtn = new JButton("Register");
        registerBtn.setForeground(new Color(39, 55, 85));
        registerBtn.setBorderPainted(false);
        registerBtn.setBackground(new Color(255, 255, 255));
        registerBtn.setBounds(237, 448, 89, 23);
        registerBtn.setFont(new Font("Tahoma", Font.PLAIN, 15));
        registerBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                loginPanel.setVisible(false);
                registerPanel.setVisible(true);
            }
        });
        panel.add(registerBtn);

        return panel;
    }

    private JPanel createRegisterPanel() {
    JPanel panel = new JPanel();
    panel.setLayout(null);
    panel.setBackground(new Color(39, 55, 85));

    JLabel register_lbl = new JLabel("REGISTER");
    register_lbl.setForeground(new Color(255, 250, 250));
    register_lbl.setFont(new Font("Tahoma", Font.BOLD, 40));
    register_lbl.setBounds(95, 50, 213, 84);
    panel.add(register_lbl);

    JLabel reg_user = new JLabel("Username");
    reg_user.setForeground(new Color(255, 250, 250));
    reg_user.setFont(new Font("Tahoma", Font.PLAIN, 15));
    reg_user.setBounds(37, 131, 73, 25);
    panel.add(reg_user);

    JPanel regUserPanel = createRoundedPanel();
    regUserPanel.setBounds(37, 167, 323, 30);
    panel.add(regUserPanel);

    reg_user_input = new JTextField();
    reg_user_input.setBounds(0, 0, 323, 30);
    regUserPanel.add(reg_user_input);

    JLabel reg_lastname = new JLabel("User's Last Name");
    reg_lastname.setForeground(new Color(255, 250, 250));
    reg_lastname.setFont(new Font("Tahoma", Font.PLAIN, 15));
    reg_lastname.setBounds(37, 203, 150, 25);
    panel.add(reg_lastname);

    JPanel regLastnamePanel = createRoundedPanel();
    regLastnamePanel.setBounds(37, 239, 323, 30);
    panel.add(regLastnamePanel);

    reg_lastname_input = new JTextField();
    reg_lastname_input.setBounds(0, 0, 323, 30);
    regLastnamePanel.add(reg_lastname_input);

    JLabel reg_pass = new JLabel("Password");
    reg_pass.setForeground(new Color(255, 250, 250));
    reg_pass.setFont(new Font("Tahoma", Font.PLAIN, 15));
    reg_pass.setBounds(37, 275, 73, 25);
    panel.add(reg_pass);

    JPanel regPassPanel = createRoundedPanel();
    regPassPanel.setBounds(37, 311, 323, 30);
    panel.add(regPassPanel);

    reg_password_input = new JPasswordField();
    reg_password_input.setBounds(0, 0, 323, 30);
    regPassPanel.add(reg_password_input);

    JLabel confirm_pass = new JLabel("Confirm Password");
    confirm_pass.setForeground(new Color(255, 250, 250));
    confirm_pass.setFont(new Font("Tahoma", Font.PLAIN, 15));
    confirm_pass.setBounds(37, 347, 150, 25);
    panel.add(confirm_pass);

    JPanel confirmPassPanel = createRoundedPanel();
    confirmPassPanel.setBounds(37, 383, 323, 30);
    panel.add(confirmPassPanel);

    JPasswordField confirm_password_input = new JPasswordField();
    confirm_password_input.setBounds(0, 0, 323, 30);
    confirmPassPanel.add(confirm_password_input);

    JButton registerBtn = new JButton("Register");
    registerBtn.setFont(new Font("Tahoma", Font.PLAIN, 15));
    registerBtn.setForeground(new Color(39, 55, 85));
    registerBtn.setBackground(new Color(255, 255, 255));
    registerBtn.setBorderPainted(false);
    registerBtn.setBounds(220, 463, 89, 23); // Adjusted size to match the login button
    registerBtn.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            String lastname = reg_lastname_input.getText();
            String username = reg_user_input.getText();
            String password = new String(reg_password_input.getPassword());
            String confirmPassword = new String(confirm_password_input.getPassword());

            if (!password.equals(confirmPassword)) {
                JOptionPane.showMessageDialog(null, "Passwords do not match!");
                return; // Abort registration
            }

            try (Connection conn = getConnection()) {
                // Insert new user into the database
                AccountManager.recordNewUser(conn, lastname, username, password);

                // Show login panel after successful registration
                registerPanel.setVisible(false);
                loginPanel.setVisible(true);
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
                ex.printStackTrace();
            }
        }
    });
    panel.add(registerBtn);

    // Adjusted position for "Already Have an Account?" text
    JLabel alreadyHaveAccount = new JLabel("Already Have an Account?");
    alreadyHaveAccount.setForeground(new Color(255, 255, 255));
    alreadyHaveAccount.setFont(new Font("Tahoma", Font.PLAIN, 10));
    alreadyHaveAccount.setBounds(57, 445, 200, 20); // Adjusted position to the right side
    panel.add(alreadyHaveAccount);

    // Adjusted position for login button
    JButton loginBtn = new JButton("Login");
    loginBtn.setForeground(new Color(39, 55, 85));
    loginBtn.setFont(new Font("Tahoma", Font.PLAIN, 15));
    loginBtn.setBorderPainted(false);
    loginBtn.setBackground(new Color(255, 255, 255));
    loginBtn.setBounds(70, 463, 89, 23); // Adjusted position to the right side
    loginBtn.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            loginPanel.setVisible(true);
            registerPanel.setVisible(false);
        }
    });
    panel.add(loginBtn);

    // Image on register panel
    JLabel registerImageLabel = new JLabel();
    registerImageLabel.setIcon(new ImageIcon("src/Images/register.png")); // Adjusted path
    registerImageLabel.setBounds(400, 0, 400, 561); // Adjusted bounds for the register panel area
    panel.add(registerImageLabel);

    return panel;
}


    private JPanel createRoundedPanel() {
        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getBackground()); // Set background color
                g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 30, 30);
                g2.dispose();
            }
        };
        panel.setOpaque(false); // Make the panel transparent
        panel.setLayout(null);
        return panel;
    }
}
