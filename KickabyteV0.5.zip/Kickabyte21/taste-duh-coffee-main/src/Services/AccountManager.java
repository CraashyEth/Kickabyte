package Services;

import Models.Cashier;
import java.sql.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class AccountManager {
    private static final String HASH_ALGORITHM = "SHA-256";

    public static Cashier getUserByUsername(String username) {
        try {
            Connection sqlConnection = DBManager.getConnection();
            PreparedStatement sqlStatement = sqlConnection.prepareStatement("SELECT * FROM cashier_accounts WHERE login_username = ?");
            sqlStatement.setString(1, username);
            ResultSet queryResults = sqlStatement.executeQuery();
            if (queryResults.next()) {
                return new Cashier(queryResults.getInt(1), queryResults.getString(2), queryResults.getString(3), queryResults.getString(4));
            } else {
                return null;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static void recordNewUser(Connection conn, String lastname, String username, String password) throws SQLException {
        String sql = "INSERT INTO cashier_accounts (cashier_lname, login_username, login_password) VALUES (?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, lastname);
            pstmt.setString(2, username);
            pstmt.setString(3, hashPassword(password)); // Hash the password before storing
            pstmt.executeUpdate();
        }
    }

    public static String getUsernameByID(int cashierID) {
        try {
            Connection sqlConnection = DBManager.getConnection();
            PreparedStatement sqlStatement = sqlConnection.prepareStatement("SELECT login_username FROM cashier_accounts WHERE cashier_id = ?");
            sqlStatement.setInt(1, cashierID);
            ResultSet queryResults = sqlStatement.executeQuery();
            if (queryResults.next()) {
                return queryResults.getString("login_username");
            } else {
                return null;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static boolean checkForMatch(String username, String inputPassword) {
        try {
            Connection sqlConnection = DBManager.getConnection();
            PreparedStatement sqlStatement = sqlConnection.prepareStatement(
                   "SELECT login_password FROM `point_of_sale`.cashier_accounts WHERE login_username = ?");
            sqlStatement.setString(1, username);

            ResultSet resultSet = sqlStatement.executeQuery();

            if (resultSet.next()) {
                // Retrieve the stored hashed password from the result set as a string
                String storedHashedPassword = resultSet.getString("login_password");

                // Verify the input password against the stored hashed password
                boolean passwordMatch = verifyPassword(inputPassword, storedHashedPassword);

                return passwordMatch;
            } else {
                // No matching username found
                return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    private static boolean verifyPassword(String inputPassword, String storedHashedPassword) {
        try {
            MessageDigest digest = MessageDigest.getInstance(HASH_ALGORITHM);
            byte[] encodedHash = digest.digest(inputPassword.getBytes());

            // Convert the byte array to a hex string for comparison
            StringBuilder hexStringBuilder = new StringBuilder(2 * encodedHash.length);
            for (byte b : encodedHash) {
                hexStringBuilder.append(String.format("%02x", b & 0xFF));
            }
            String inputHashedPassword = hexStringBuilder.toString();

            // Compare the input hashed password with the stored hashed password
            return inputHashedPassword.equals(storedHashedPassword);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static void recordNewUser(String lname, String username, String password) {
        try {
            // Hash the password before storing it
            String hashedPassword = hashPassword(password);

            Connection sqlConnection = DBManager.getConnection();
            PreparedStatement sqlStatement = sqlConnection.prepareStatement(
                    "INSERT INTO cashier_accounts (cashier_lname, login_username, login_password) VALUES (?, ?, ?)");
            sqlStatement.setString(1, lname);
            sqlStatement.setString(2, username);
            sqlStatement.setString(3, hashedPassword);  // Store the hashed password as a string
            sqlStatement.execute();
            sqlConnection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static String hashPassword(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance(HASH_ALGORITHM);
            byte[] encodedHash = digest.digest(password.getBytes());

            // Convert the byte array to a hex string for storage
            StringBuilder hexStringBuilder = new StringBuilder(2 * encodedHash.length);
            for (byte b : encodedHash) {
                hexStringBuilder.append(String.format("%02x", b & 0xFF));
            }
            return hexStringBuilder.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }

    // Method to get the currently logged-in username (you may need to adjust this based on your application's logic)
    public static String getCurrentUsername() {
        // Implement actual logic to retrieve current user's username
        // For example, you might retrieve it from a session or security context
        // Here's a placeholder implementation:
        String currentUsername = ""; // Placeholder for actual logic

        // Example: Retrieve current username from session or security context
        //currentUsername = DBManager.getCurrentUsername();

        return currentUsername;
    }

    // Method to retrieve current user's last name
    public static String getCurrentUserLastName() {
        // Implement actual logic to retrieve current user's last name
        // Similar to getCurrentUsername(), retrieve it from session or security context
        String currentLastName = ""; // Placeholder for actual logic

        // Example: Retrieve current last name from session or security context
        //currentLastName = DBManager.getCurrentUserLastName();

        return currentLastName;
    }


    // Method to get user details (username and last name) from the database
    public static String[] getUserDetails(String username) {
        String[] userDetails = new String[2];
        try {
            Connection conn = DBManager.getConnection();
            String sql = "SELECT login_username, cashier_lname FROM cashier_accounts WHERE login_username = ?";

            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, username);
                ResultSet rs = stmt.executeQuery();

                if (rs.next()) {
                    userDetails[0] = rs.getString("login_username");
                    userDetails[1] = rs.getString("cashier_lname");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return userDetails;
    }
}
