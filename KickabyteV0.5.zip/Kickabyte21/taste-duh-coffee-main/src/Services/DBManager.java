package Services;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBManager {
    static String port = "3307";
    static String DBIdentifier = "point_of_sale";
    static String masterUsername = "root";
    static String masterPassword = "your_password";

    public static Connection getConnection() throws SQLException {
        String url = "jdbc:mysql://localhost:" + port + "/" + DBIdentifier;
        return DriverManager.getConnection(url, masterUsername, masterPassword);
    }

    public static void closeConnection(Connection currConnection) throws SQLException {
        if (currConnection != null && !currConnection.isClosed()) {
            currConnection.close();
        }
    }
}
